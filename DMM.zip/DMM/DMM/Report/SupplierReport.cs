﻿using DevExpress.XtraReports.UI;
using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;

namespace DMM.Report
{
    public partial class SupplierReport : DevExpress.XtraReports.UI.XtraReport
    {
        public SupplierReport()
        {
            InitializeComponent();
        }

    }
}
